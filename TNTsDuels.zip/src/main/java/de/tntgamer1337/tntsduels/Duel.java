package de.tntgamer1337.tntsduels;

import de.tntgamer1337.tntsduels.items.giveItems;
import de.tntgamer1337.tntsduels.managers.ArenaManager;
import org.bukkit.ChatColor;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.metadata.MetadataValue;
import org.bukkit.plugin.Plugin;

public class Duel {
    public static void startDuel(Player p, Player p1, String arenaName) {
        Location lobbyLocation = ArenaManager.getArenaLobby(arenaName);
        Location loc1 = ArenaManager.getArenaDuel(arenaName);
        Location loc2 = ArenaManager.getArenaDuel2(arenaName);
        if (loc1 == null)
            return;
        if (loc2 == null)
            return;
        if (lobbyLocation == null)
            return;
        String kitName = ArenaManager.getArenaKitName(arenaName).toLowerCase();
        if (kitName == null)
            return;
        p.setBedSpawnLocation(lobbyLocation, true);
        p1.setBedSpawnLocation(lobbyLocation, true);
        p.sendMessage(String.valueOf(TNTsDuels.prefix) + ChatColor.GOLD + "Starting duel with: " + p1.getName());
        p1.sendMessage(String.valueOf(TNTsDuels.prefix) + ChatColor.GOLD + "Starting duel with: " + p.getName());
        p.removeMetadata("inQueue", (Plugin)TNTsDuels.getInstance());
        p1.removeMetadata("inQueue", (Plugin)TNTsDuels.getInstance());
        p.setMetadata("inDuel", (MetadataValue)new FixedMetadataValue((Plugin)TNTsDuels.getInstance(), arenaName));
        p1.setMetadata("inDuel", (MetadataValue)new FixedMetadataValue((Plugin)TNTsDuels.getInstance(), arenaName));
        p.setMetadata("DuelType", (MetadataValue)new FixedMetadataValue((Plugin)TNTsDuels.getInstance(), kitName));
        p1.setMetadata("DuelType", (MetadataValue)new FixedMetadataValue((Plugin)TNTsDuels.getInstance(), kitName));
        p.teleport(loc1);
        p1.teleport(loc2);
        if (kitName.equals("cpvp")) {
            giveItems.giveCPvPItems(p);
            giveItems.giveCPvPItems(p1);
        } else if (kitName.equals("default")) {
            giveItems.giveNormalFightItems(p);
            giveItems.giveNormalFightItems(p1);
        } else if (kitName.equals("iron")) {
            giveItems.giveIronItems(p);
            giveItems.giveIronItems(p1);
        } else {
            giveItems.giveNormalFightItems(p);
            giveItems.giveNormalFightItems(p1);
        }
        p.setGameMode(GameMode.SURVIVAL);
        p1.setGameMode(GameMode.SURVIVAL);
    }
}