package de.tntgamer1337.tntsduels;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;

public class BrokenBlock {
    private Location location;
    private Material material;
    private World world;

    public BrokenBlock(Location loc, Material mat, World wor) {
        location = loc;
        material = mat;
        world = wor;
        Bukkit.getConsoleSender().sendMessage(TNTsDuels.prefix+"New BrokenBlock: Material: "+material.name()+", Location: "+location.toString()+", World: "+world.getName());
    }

    public Location getLocation() {
        return location;
    }

    public Material getMaterial() {
        return material;
    }

    public World getWorld() {
        return world;
    }
}
