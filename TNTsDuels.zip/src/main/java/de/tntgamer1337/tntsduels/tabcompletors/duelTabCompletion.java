package de.tntgamer1337.tntsduels.tabcompletors;

import de.tntgamer1337.tntsduels.managers.ArenaManager;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.util.StringUtil;

import java.util.ArrayList;
import java.util.List;

public class duelTabCompletion implements TabCompleter {
    private static List<String> argsZeroCommands = new ArrayList<>();
    private static List<String> argsOneCommands = new ArrayList<>();

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String label, String[] args) {
        argsZeroCommands.clear();
        for (Player player : Bukkit.getOnlinePlayers()) {
            argsZeroCommands.add(player.getName());
        }
        argsOneCommands.clear();
        argsOneCommands.addAll(ArenaManager.getArenas());
        List<String> completions = new ArrayList<>();
        if (args.length == 1) {
            StringUtil.copyPartialMatches(args[0], argsZeroCommands, completions);
        } else if (args.length == 2) {
            StringUtil.copyPartialMatches(args[1], argsOneCommands, completions);
        } else {
            StringUtil.copyPartialMatches(args[0], argsZeroCommands, completions);
        }
        return completions;
    }
}
