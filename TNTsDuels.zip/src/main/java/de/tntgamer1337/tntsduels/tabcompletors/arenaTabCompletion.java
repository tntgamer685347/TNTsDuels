package de.tntgamer1337.tntsduels.tabcompletors;

import de.tntgamer1337.tntsduels.managers.ArenaManager;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.util.StringUtil;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class arenaTabCompletion implements TabCompleter {
    private static String[] argsZeroCommands = { "create", "list", "setkit", "help", "setlobby", "setspawn1", "setspawn2" };
    private static String[] argsOneCommands = { "default", "cpvp", "iron" };
    private static List<String> argsTwoCommands = new ArrayList<>();

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String label, String[] args) {
        List<String> completions = new ArrayList<>();
        argsTwoCommands.clear();
        argsTwoCommands.addAll(ArenaManager.getArenas());
        if (args.length == 1) {
            StringUtil.copyPartialMatches(args[0], Arrays.asList(argsZeroCommands), completions);
        } else if (args.length == 2) {
            StringUtil.copyPartialMatches(args[1], argsTwoCommands, completions);
        } else if (args.length == 3) {
            StringUtil.copyPartialMatches(args[2], Arrays.asList(argsOneCommands), completions);
        } else {
            for (Player player : Bukkit.getOnlinePlayers()) {
                completions.add(player.getName());
            }
        }
        return completions;
    }
}
