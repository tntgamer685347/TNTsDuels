package de.tntgamer1337.tntsduels.tabcompletors;

import de.tntgamer1337.tntsduels.managers.ArenaManager;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.util.StringUtil;

import java.util.ArrayList;
import java.util.List;

public class queueTabCompletion implements TabCompleter {
    private static List<String> arenas = new ArrayList<>();
    private static List<String> players = new ArrayList<>();

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String label, String[] args) {
        arenas.clear();
        players.clear();
        arenas.addAll(ArenaManager.getArenas());
        for (Player player : Bukkit.getOnlinePlayers()) {
            players.add(player.getName());
        }
        List<String> completions = new ArrayList<>();
        if (args.length == 1) {
            StringUtil.copyPartialMatches(args[0], arenas, completions);
        } else {
            StringUtil.copyPartialMatches(args[args.length-1], players, completions);
        }

        return completions;
    }
}
