package de.tntgamer1337.tntsduels.managers;

import org.bukkit.Location;

import java.util.List;

public class ArenaManager {
    public static void createArena(String Name) {
        ConfigManager.set("arenas", "Arenas."+Name, Integer.valueOf(Name.length()));
    }

    public static void setArenaSpawn1(String Name, Location warpPointDuel) {
        ConfigManager.set("arenas", "Arenas."+String.valueOf(Name) + ".wp1", warpPointDuel);
    }

    public static void setArenaSpawn2(String Name, Location warpPointDuel2) {
        ConfigManager.set("arenas", "Arenas."+String.valueOf(Name) + ".wp2", warpPointDuel2);
    }

    public static void setArenaKit(String Name, String kitName) {
        ConfigManager.set("arenas", "Arenas."+String.valueOf(Name) + ".kit", kitName);
    }

    public static void setArenaLobby(String Name, Location ArenaLobbyLocation) {
        ConfigManager.set("arenas", "Arenas."+String.valueOf(Name) + ".lobby", ArenaLobbyLocation);
    }

    public static Location getArenaLobby(String Name) {
        return ConfigManager.getLoc("arenas", "Arenas."+String.valueOf(Name) + ".lobby");
    }

    public static Location getArenaDuel(String Name) {
        return ConfigManager.getLoc("arenas", "Arenas."+String.valueOf(Name) + ".wp1");
    }

    public static Location getArenaDuel2(String Name) {
        return ConfigManager.getLoc("arenas", "Arenas."+String.valueOf(Name) + ".wp2");
    }

    public static String getArenaKitName(String arenaName) {
        return ConfigManager.getString("arenas", "Arenas."+String.valueOf(arenaName) + ".kit");
    }

    public static List<String> getArenas() {
        return ConfigManager.getSection("arenas", "Arenas");
    }
}
