package de.tntgamer1337.tntsduels.managers;

import de.tntgamer1337.tntsduels.TNTsDuels;
import de.tntgamer1337.tntsduels.builders.ConfigFileBuilder;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;

public class ConfigManager {
    public static void setUpPlayer(Player p) {
        TNTsDuels plugin = TNTsDuels.getInstance();
        FileConfiguration config = plugin.getConfig();
        String uuid = p.getUniqueId().toString();
        config.set(uuid, p.getName());
        config.set(String.valueOf(uuid) + "." + p.getName() + ".games", Integer.valueOf(0));
        config.set(String.valueOf(uuid) + "." + p.getName() + ".wins", Integer.valueOf(0));
        plugin.saveConfig();
    }

    public static String getString(String configName, String key) {
        FileConfiguration config = ConfigFileBuilder.BuildAndGetConfig(configName);
        return config.getString(key);
    }

    public static int getInt(String configName, String key) {
        FileConfiguration config = ConfigFileBuilder.BuildAndGetConfig(configName);
        return config.getInt(key);
    }

    public static void set(String configName, String key, Object value) {
        FileConfiguration config = ConfigFileBuilder.BuildAndGetConfig(configName);
        config.set(key, value);
        try {
            config.save(new File("plugins/TNTsDuels/" + configName + ".yml"));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static Location getLoc(String configName, String key) {
        FileConfiguration config = ConfigFileBuilder.BuildAndGetConfig(configName);
        Location loc = (Location)config.get(key);
        return loc;
    }

    public static Object getObj(String configName, String key) {
        FileConfiguration config = ConfigFileBuilder.BuildAndGetConfig(configName);
        return config.get(key);
    }

    public static List<String> getSection (String configName, String sectionName) {
        List<String> inSection = new ArrayList<>();
        FileConfiguration config = ConfigFileBuilder.BuildAndGetConfig(configName);
        //Bukkit.getConsoleSender().sendMessage(config.getConfigurationSection(sectionName).getKeys(false).toString());
        inSection.addAll(config.getConfigurationSection(sectionName).getKeys(false));
        return inSection;
    }
}
