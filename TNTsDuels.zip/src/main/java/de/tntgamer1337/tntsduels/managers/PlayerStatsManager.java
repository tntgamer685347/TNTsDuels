package de.tntgamer1337.tntsduels.managers;

import org.bukkit.entity.Player;

public class PlayerStatsManager {
    public static void addGamePlayed(Player p) {
        String uuid = p.getUniqueId().toString();
        int currentGames = ConfigManager.getInt("config", String.valueOf(uuid) + "." + p.getName() + ".games");
        ConfigManager.set("config", String.valueOf(uuid) + "." + p.getName() + ".games", Integer.valueOf(currentGames + 1));
    }

    public static void addWin(Player p) {
        String uuid = p.getUniqueId().toString();
        int currentWins = ConfigManager.getInt("config", String.valueOf(uuid) + "." + p.getName() + ".wins");
        ConfigManager.set("config", String.valueOf(uuid) + "." + p.getName() + ".wins", Integer.valueOf(currentWins + 1));
    }

    public static int getGamesPlayed(Player p) {
        String uuid = p.getUniqueId().toString();
        return ConfigManager.getInt("config", String.valueOf(uuid) + "." + p.getName() + ".games");
    }

    public static int getWins(Player p) {
        String uuid = p.getUniqueId().toString();
        return ConfigManager.getInt("config", String.valueOf(uuid) + "." + p.getName() + ".wins");
    }
}
