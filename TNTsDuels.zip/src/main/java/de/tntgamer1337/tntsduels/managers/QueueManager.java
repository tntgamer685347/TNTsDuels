package de.tntgamer1337.tntsduels.managers;

import de.tntgamer1337.tntsduels.Duel;
import de.tntgamer1337.tntsduels.TNTsDuels;
import java.util.ArrayList;
import java.util.List;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.metadata.MetadataValue;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;

public class QueueManager {
    public static void setInQueue(Player p, String arenaName) {
        if (!p.hasMetadata("inDuel") && !p.hasMetadata("inQueue")) {
            p.setMetadata("inQueue", (MetadataValue)new FixedMetadataValue((Plugin)TNTsDuels.getInstance(), arenaName));
            Queue(p, arenaName);
            p.sendMessage(String.valueOf(TNTsDuels.prefix) + ChatColor.GREEN + "Added you to Queue, arena: " + arenaName);
        } else {
            p.sendMessage(String.valueOf(TNTsDuels.prefix) + ChatColor.RED + "Already in queue or in a duel!");
        }
    }

    public static void Queue(final Player player, final String arenaName) {
        (new BukkitRunnable() {
            public void run() {
                if (player.hasMetadata("inQueue")) {
                    ArrayList<String> playerInQueue = new ArrayList<>();
                    for (Player pl : Bukkit.getOnlinePlayers()) {
                        if (!pl.getName().equals(player.getName()) &&
                                pl.hasMetadata("inQueue")) {
                            String targetArenaName = null;
                            List<MetadataValue> metadata = pl.getMetadata("inQueue");
                            for (MetadataValue value : metadata) {
                                if (value.getOwningPlugin().getName().equals("TNTsDuels")) {
                                    targetArenaName = value.asString();
                                    break;
                                }
                            }
                            if (targetArenaName != null && targetArenaName.equals(arenaName))
                                playerInQueue.add(pl.getName());
                        }
                    }
                    if (playerInQueue.size() >= 1) {
                        String playerName1 = playerInQueue.get(0);
                        Player player1 = Bukkit.getPlayer(playerName1);
                        Duel.startDuel(player, player1, arenaName);
                        cancel();
                    }
                } else {
                    cancel();
                }
            }
        }).runTaskTimer((Plugin)TNTsDuels.getInstance(), 0L, 40L);
    }
}
