package de.tntgamer1337.tntsduels.builders;

import java.io.File;
import java.io.IOException;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

public class ConfigFileBuilder {
    public static FileConfiguration BuildAndGetConfig(String name) {
        String path = "plugins/TNTsDuels/" + name + ".yml";
        File customFile = new File(path);
        if (!customFile.exists())
            try {
                customFile.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
        return (FileConfiguration)YamlConfiguration.loadConfiguration(customFile);
    }
}
