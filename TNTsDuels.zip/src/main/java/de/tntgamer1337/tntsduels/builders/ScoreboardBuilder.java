package de.tntgamer1337.tntsduels.builders;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Scoreboard;

public abstract class ScoreboardBuilder {
    private final Scoreboard scoreboard;

    private final Objective objective;

    private final Player p;

    public ScoreboardBuilder(Player p, String displayName) {
        this.p = p;
        if (p.getScoreboard().equals(Bukkit.getScoreboardManager().getMainScoreboard()))
            p.setScoreboard(Bukkit.getScoreboardManager().getNewScoreboard());
        this.scoreboard = p.getScoreboard();
        if (p.getScoreboard().getObjective("display") != null)
            p.getScoreboard().getObjective("display").unregister();
        this.objective = this.scoreboard.registerNewObjective(displayName, "dummy");
        this.objective.setDisplaySlot(DisplaySlot.SIDEBAR);
        createScoreboard(p);
        update(p);
    }

    public abstract void createScoreboard(Player paramPlayer);

    public abstract void update(Player paramPlayer);

    public void setDisplayName(String name) {
        this.objective.setDisplayName(name);
    }

    public void setScore(String content, int score) {
        this.objective.getScore(content).setScore(score);
    }

    public void deleteScore(String content) {
        this.scoreboard.resetScores(content);
    }
}