package de.tntgamer1337.tntsduels.commands;

import de.tntgamer1337.tntsduels.TNTsDuels;
import de.tntgamer1337.tntsduels.managers.ArenaManager;
import de.tntgamer1337.tntsduels.utilitys.Color;
import org.apache.commons.lang.RandomStringUtils;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.List;
import java.util.Random;

public class arenaCommand implements CommandExecutor {
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (sender instanceof Player) {
            Player p = (Player)sender;
            if (args.length == 0) {
                sendHelpMSG((CommandSender)p, "help");
                return true;
            }
            switch (args[0]) {
                case "create":
                    if (args.length != 2) {
                        sendHelpMSG((CommandSender)p, args[0]);
                        return true;
                    }
                    ArenaManager.createArena(args[1]);
                    p.sendMessage(String.valueOf(TNTsDuels.prefix) + ChatColor.GREEN + "Successfully created arena: " + args[1]);
                    return true;
                case "list":
                    List<String> arenas = ArenaManager.getArenas();
                    for (String arena : arenas) {
                        p.sendMessage(String.valueOf(TNTsDuels.prefix) + ChatColor.AQUA + arena);
                    }
                    return true;
                case "setkit":
                    if (args.length != 3) {
                        sendHelpMSG((CommandSender)p, args[0]);
                        return true;
                    }
                    if (args[2].toLowerCase().equals("default") || args[2].toLowerCase().equals("iron") || args[2].toLowerCase().equals("cpvp")) {
                        ArenaManager.setArenaKit(args[1], args[2].toLowerCase());
                        p.sendMessage(String.valueOf(TNTsDuels.prefix) + ChatColor.GREEN + "Successfully set Arena kit to: " + args[2].toLowerCase());
                        return true;
                    }
                    sendHelpMSG((CommandSender)p, args[0]);
                    return true;
                case "setlobby":
                    if (args.length != 2) {
                        sendHelpMSG((CommandSender)p, args[0]);
                        return true;
                    }
                    ArenaManager.setArenaLobby(args[1], p.getLocation());
                    p.sendMessage(String.valueOf(TNTsDuels.prefix) + ChatColor.GREEN + "Successfully set Arena lobby to: (x" + p.getLocation().getX() + ", y" + p.getLocation().getY() + ", z" + p.getLocation().getZ() + ")");
                    return true;
                case "setspawn1":
                    if (args.length != 2) {
                        sendHelpMSG((CommandSender)p, args[0]);
                        return true;
                    }
                    ArenaManager.setArenaSpawn1(args[1], p.getLocation());
                    p.sendMessage(String.valueOf(TNTsDuels.prefix) + ChatColor.GREEN + "Successfully set spawn1 to: (x" + p.getLocation().getX() + ", y" + p.getLocation().getY() + ", z" + p.getLocation().getZ() + ")");
                    return true;
                case "setspawn2":
                    if (args.length != 2) {
                        sendHelpMSG((CommandSender)p, args[0]);
                        return true;
                    }
                    ArenaManager.setArenaSpawn2(args[1], p.getLocation());
                    p.sendMessage(String.valueOf(TNTsDuels.prefix) + ChatColor.GREEN + "Successfully set spawn2 to: (x" + p.getLocation().getX() + ", y" + p.getLocation().getY() + ", z" + p.getLocation().getZ() + ")");
                    return true;
            }
            sendHelpMSG((CommandSender)p, "help");
        }
        return true;
    }

    public void sendHelpMSG(CommandSender p, String type) {
        switch (type) {
            case "create":
                p.sendMessage(String.valueOf(TNTsDuels.prefix) + ChatColor.RED + "Usage: /arena create <Arenaname> | creates the arena.");
                return;
            case "setkit":
                p.sendMessage(String.valueOf(TNTsDuels.prefix) + ChatColor.RED + "Usage: /arena setkit <Arenaname> <kitName> | sets the kit for your arena, options: (default, iron, cpvp)");
                return;
            case "help":
                p.sendMessage(String.valueOf(TNTsDuels.prefix) + Color.Colorize("&cHelp: Commands: &4(</arena list | lists arenas.>, </arena create <Arenaname> | creates the arena.>, </arena setspawn1 <Arenaname> | sets the first spawn at your location.>, </arena setspawn2 <Arenaname> | sets the second spawn at your location.>, </arena setkit <Arenaname> <kitName> | sets the kit for your arena, options: (default, iron, cpvp)>, </arena setlobby <Arenaname> | sets the lobby from the arena at your location.>)"));
                return;
            case "setlobby":
                p.sendMessage(String.valueOf(TNTsDuels.prefix) + ChatColor.RED + "Usage: /arena setlobby <Arenaname> | sets the lobby from the arena at your location.");
                return;
            case "setspawn1":
                p.sendMessage(String.valueOf(TNTsDuels.prefix) + ChatColor.RED + "Usage: /arena setspawn1 <Arenaname> | sets the first spawn at your location.");
                return;
            case "setspawn2":
                p.sendMessage(String.valueOf(TNTsDuels.prefix) + ChatColor.RED + "Usage: /arena setspawn2 <Arenaname> | sets the second spawn at your location.");
                return;
        }
        p.sendMessage(String.valueOf(TNTsDuels.prefix) + ChatColor.RED + "Unknown Command.");
    }
}
