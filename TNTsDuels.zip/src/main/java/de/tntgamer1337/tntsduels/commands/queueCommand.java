package de.tntgamer1337.tntsduels.commands;

import de.tntgamer1337.tntsduels.TNTsDuels;
import de.tntgamer1337.tntsduels.managers.ArenaManager;
import de.tntgamer1337.tntsduels.managers.QueueManager;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class queueCommand implements CommandExecutor {
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (sender instanceof Player) {
            Player p = (Player)sender;
            try {
                Location DuelLocation = ArenaManager.getArenaDuel(args[0]);
                Location DuelLocation2 = ArenaManager.getArenaDuel2(args[0]);
                Location lobbyLocation = ArenaManager.getArenaLobby(args[0]);
                String kitName = ArenaManager.getArenaKitName(args[1]).toLowerCase();
                if (DuelLocation == null) {
                    p.sendMessage(String.valueOf(TNTsDuels.prefix) + ChatColor.RED + "The Arena " + args[1] + " isnt setup yet.");
                    return true;
                }
                if (DuelLocation2 == null) {
                    p.sendMessage(String.valueOf(TNTsDuels.prefix) + ChatColor.RED + "The Arena " + args[1] + " isnt setup yet.");
                    return true;
                }
                if (lobbyLocation == null) {
                    p.sendMessage(String.valueOf(TNTsDuels.prefix) + ChatColor.RED + "The Arena " + args[1] + " isnt setup yet.");
                    return true;
                }
                if (kitName == null) {
                    p.sendMessage(String.valueOf(TNTsDuels.prefix) + ChatColor.RED + "The Arena " + args[1] + " isnt setup yet.");
                    return true;
                }
                QueueManager.setInQueue(p, args[0]);
            } catch (Exception err) {
                helpMSG(sender);
            }
        }
        return true;
    }

    public void helpMSG(CommandSender p) {
        p.sendMessage(String.valueOf(TNTsDuels.prefix) + ChatColor.RED + "Usage: /queue <arenaName>");
    }
}
