package de.tntgamer1337.tntsduels.commands;

import de.tntgamer1337.tntsduels.TNTsDuels;
import de.tntgamer1337.tntsduels.items.giveItems;
import de.tntgamer1337.tntsduels.managers.ArenaManager;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.metadata.MetadataValue;
import org.bukkit.plugin.Plugin;

public class duelCommand implements CommandExecutor {
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (sender instanceof Player) {
            if (args.length != 2) {
                sendHelpMSG(sender);
                return false;
            }
            if (sender instanceof Player) {
                Player p = (Player)sender;
                if (p.hasPermission("tntsduels.instaduel")) {
                    if (!p.getName().equals(args[0])) {
                        Player p2 = Bukkit.getPlayer(args[0]);
                        if (p2 != null) {
                            Location DuelLocation = ArenaManager.getArenaDuel(args[1]);
                            Location DuelLocation2 = ArenaManager.getArenaDuel2(args[1]);
                            Location lobbyLocation = ArenaManager.getArenaLobby(args[1]);
                            if (DuelLocation == null) {
                                p.sendMessage(String.valueOf(TNTsDuels.prefix) + ChatColor.RED + "The Arena " + args[1] + " isnt setup yet.");
                                return true;
                            }
                            if (DuelLocation2 == null) {
                                p.sendMessage(String.valueOf(TNTsDuels.prefix) + ChatColor.RED + "The Arena " + args[1] + " isnt setup yet.");
                                return true;
                            }
                            if (lobbyLocation == null) {
                                p.sendMessage(String.valueOf(TNTsDuels.prefix) + ChatColor.RED + "The Arena " + args[1] + " isnt setup yet.");
                                return true;
                            }
                            String kitName = ArenaManager.getArenaKitName(args[1]).toLowerCase();
                            if (kitName == null) {
                                p.sendMessage(String.valueOf(TNTsDuels.prefix) + ChatColor.RED + "The Arena " + args[1] + " isnt setup yet.");
                                return true;
                            }
                            p.setMetadata("DuelType", (MetadataValue)new FixedMetadataValue((Plugin)TNTsDuels.getInstance(), kitName));
                            p2.setMetadata("DuelType", (MetadataValue)new FixedMetadataValue((Plugin)TNTsDuels.getInstance(), kitName));
                            if (kitName.equals("cpvp")) {
                                giveItems.giveCPvPItems(p);
                                giveItems.giveCPvPItems(p2);
                            } else if (kitName.equals("default")) {
                                giveItems.giveNormalFightItems(p);
                                giveItems.giveNormalFightItems(p2);
                            } else if (kitName.equals("iron")) {
                                giveItems.giveIronItems(p);
                                giveItems.giveIronItems(p2);
                            } else {
                                giveItems.giveNormalFightItems(p);
                                giveItems.giveNormalFightItems(p2);
                            }
                            p.setMetadata("inDuel", (MetadataValue)new FixedMetadataValue((Plugin)TNTsDuels.getInstance(), args[1]));
                            p2.setMetadata("inDuel", (MetadataValue)new FixedMetadataValue((Plugin)TNTsDuels.getInstance(), args[1]));
                            p.setHealth(p.getMaxHealth());
                            p2.setHealth(p.getMaxHealth());
                            p.teleport(DuelLocation);
                            p2.teleport(DuelLocation2);
                            p.sendMessage(String.valueOf(TNTsDuels.prefix) + ChatColor.GREEN + "Starting Duel...");
                            return true;
                        }
                        p.sendMessage(String.valueOf(TNTsDuels.prefix) + ChatColor.RED + "Player " + args[0] + " is not Online.");
                        return true;
                    }
                    p.sendMessage(String.valueOf(TNTsDuels.prefix) + ChatColor.RED + "You cant duel Yourself.");
                    return true;
                }
                p.sendMessage(String.valueOf(TNTsDuels.prefix) + ChatColor.DARK_RED + "You dont have permission to execute this command.");
                return false;
            }
        }
        return false;
    }

    public void sendHelpMSG(CommandSender p) {
        p.sendMessage(ChatColor.RED + "Usage: /duel <player> <arenaName>");
    }
}
