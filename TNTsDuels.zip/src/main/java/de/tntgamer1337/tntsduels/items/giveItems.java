package de.tntgamer1337.tntsduels.items;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.PotionMeta;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

public class giveItems {
    public static void giveNormalFightItems(Player p) {
        ItemStack sword = new ItemStack(Material.DIAMOND_SWORD);
        ItemStack helmet = new ItemStack(Material.CHAINMAIL_HELMET);
        ItemStack chestplate = new ItemStack(Material.DIAMOND_CHESTPLATE);
        ItemMeta chestMeta = chestplate.getItemMeta();
        chestMeta.addEnchant(Enchantment.PROTECTION_ENVIRONMENTAL, 1, true);
        chestplate.setItemMeta(chestMeta);
        ItemStack leggings = new ItemStack(Material.DIAMOND_LEGGINGS);
        ItemMeta leggMeta = leggings.getItemMeta();
        leggMeta.addEnchant(Enchantment.PROTECTION_ENVIRONMENTAL, 1, true);
        leggings.setItemMeta(leggMeta);
        ItemStack boots = new ItemStack(Material.DIAMOND_BOOTS);
        ItemMeta bootMeta = boots.getItemMeta();
        bootMeta.addEnchant(Enchantment.PROTECTION_ENVIRONMENTAL, 1, true);
        boots.setItemMeta(bootMeta);
        ItemStack apples = new ItemStack(Material.GOLDEN_APPLE);
        apples.setAmount(14);
        p.getInventory().clear();
        p.getInventory().setBoots(boots);
        p.getInventory().setLeggings(leggings);
        p.getInventory().setChestplate(chestplate);
        p.getInventory().setHelmet(helmet);
        p.getInventory().setItem(0, sword);
        p.getInventory().setItem(1, apples);
    }

    public static void giveCPvPItems(Player p) {
        ItemStack sword = new ItemStack(Material.DIAMOND_SWORD);
        ItemMeta swordMeta = sword.getItemMeta();
        swordMeta.addEnchant(Enchantment.MENDING, 1, true);
        swordMeta.addEnchant(Enchantment.DAMAGE_ALL, 3, true);
        swordMeta.addEnchant(Enchantment.DURABILITY, 3, true);
        sword.setItemMeta(swordMeta);
        ItemStack helmet = new ItemStack(Material.DIAMOND_HELMET);
        ItemMeta helmetMeta = helmet.getItemMeta();
        helmetMeta = cpvpEnchantArmor(helmetMeta);
        helmet.setItemMeta(helmetMeta);
        ItemStack chestplate = new ItemStack(Material.DIAMOND_CHESTPLATE);
        ItemMeta chestMeta = chestplate.getItemMeta();
        chestMeta = cpvpEnchantArmor(chestMeta);
        chestplate.setItemMeta(chestMeta);
        ItemStack leggings = new ItemStack(Material.DIAMOND_LEGGINGS);
        ItemMeta leggMeta = leggings.getItemMeta();
        leggMeta = cpvpEnchantArmor(leggMeta);
        leggings.setItemMeta(leggMeta);
        ItemStack boots = new ItemStack(Material.DIAMOND_BOOTS);
        ItemMeta bootMeta = boots.getItemMeta();
        bootMeta = cpvpEnchantArmor(bootMeta);
        boots.setItemMeta(bootMeta);
        ItemStack pick = new ItemStack(Material.DIAMOND_PICKAXE);
        ItemMeta pickMeta = pick.getItemMeta();
        pickMeta = cpvpEnchantTool(pickMeta);
        pick.setItemMeta(pickMeta);
        ItemStack totem = new ItemStack(Material.TOTEM);
        ItemStack obsidian = new ItemStack(Material.OBSIDIAN);
        obsidian.setAmount(64);
        ItemStack endCrystals = new ItemStack(Material.END_CRYSTAL);
        endCrystals.setAmount(64);
        ItemStack apples = new ItemStack(Material.GOLDEN_APPLE);
        apples.setAmount(64);
        PotionEffect speedEffect = new PotionEffect(PotionEffectType.SPEED, 3600, 2);
        ItemStack potionItem = new ItemStack(Material.POTION);
        PotionMeta potionMeta = (PotionMeta)potionItem.getItemMeta();
        potionMeta.addCustomEffect(speedEffect, true);
        potionMeta.setDisplayName(ChatColor.GREEN + "Speed Potion");
        potionItem.setItemMeta((ItemMeta)potionMeta);
        p.getInventory().clear();
        p.getInventory().setBoots(boots);
        p.getInventory().setLeggings(leggings);
        p.getInventory().setChestplate(chestplate);
        p.getInventory().setHelmet(helmet);
        p.getInventory().setItemInOffHand(totem);
        p.getInventory().setItem(8, obsidian);
        p.getInventory().setItem(7, obsidian);
        p.getInventory().setItem(6, endCrystals);
        p.getInventory().setItem(5, endCrystals);
        p.getInventory().setItem(4, totem);
        p.getInventory().setItem(3, potionItem);
        p.getInventory().setItem(9, totem);
        p.getInventory().setItem(10, totem);
        p.getInventory().setItem(11, totem);
        p.getInventory().setItem(12, totem);
        p.getInventory().setItem(21, totem);
        p.getInventory().setItem(30, totem);
        p.getInventory().setItem(20, totem);
        p.getInventory().setItem(29, totem);
        p.getInventory().setItem(19, totem);
        p.getInventory().setItem(28, totem);
        p.getInventory().setItem(18, totem);
        p.getInventory().setItem(27, totem);
        p.getInventory().setItem(0, sword);
        p.getInventory().setItem(1, pick);
        p.getInventory().setItem(2, apples);
        p.getInventory().setItem(13, endCrystals);
        p.getInventory().setItem(14, endCrystals);
        p.getInventory().setItem(22, endCrystals);
        p.getInventory().setItem(23, endCrystals);
        p.getInventory().setItem(31, endCrystals);
        p.getInventory().setItem(32, endCrystals);
        p.getInventory().setItem(15, obsidian);
        p.getInventory().setItem(16, obsidian);
        p.getInventory().setItem(17, obsidian);
        p.getInventory().setItem(26, obsidian);
        p.getInventory().setItem(35, obsidian);
        p.getInventory().setItem(25, obsidian);
        p.getInventory().setItem(34, obsidian);
        p.getInventory().setItem(24, obsidian);
        p.getInventory().setItem(33, obsidian);
    }

    public static ItemMeta cpvpEnchantArmor(ItemMeta meta) {
        meta.addEnchant(Enchantment.MENDING, 1, true);
        meta.addEnchant(Enchantment.PROTECTION_ENVIRONMENTAL, 2, true);
        meta.addEnchant(Enchantment.DURABILITY, 3, true);
        return meta;
    }

    public static ItemMeta cpvpEnchantTool(ItemMeta meta) {
        meta.addEnchant(Enchantment.MENDING, 1, true);
        meta.addEnchant(Enchantment.DURABILITY, 3, true);
        meta.addEnchant(Enchantment.DIG_SPEED, 10, true);
        return meta;
    }

    public static void giveIronItems(Player p) {
        ItemStack helmet = new ItemStack(Material.CHAINMAIL_HELMET);
        ItemStack chestplate = new ItemStack(Material.IRON_CHESTPLATE);
        ItemStack leggings = new ItemStack(Material.IRON_LEGGINGS);
        ItemStack boots = new ItemStack(Material.IRON_BOOTS);
        ItemStack sword = new ItemStack(Material.IRON_SWORD);
        ItemStack rod = new ItemStack(Material.FISHING_ROD);
        ItemStack bow = new ItemStack(Material.BOW);
        ItemStack flint = new ItemStack(Material.FLINT_AND_STEEL, 1);
        flint.setDurability((short)1);
        ItemStack arrows = new ItemStack(Material.ARROW);
        arrows.setAmount(16);
        PlayerInventory playerInventory = p.getInventory();
        playerInventory.clear();
        p.getInventory().setHelmet(helmet);
        p.getInventory().setChestplate(chestplate);
        p.getInventory().setLeggings(leggings);
        p.getInventory().setBoots(boots);
        playerInventory.setItem(0, sword);
        p.getInventory().setItemInOffHand(rod);
        playerInventory.setItem(1, bow);
        playerInventory.setItem(8, flint);
        playerInventory.setItem(17, arrows);
    }
}
