package de.tntgamer1337.tntsduels.utilitys;

import org.bukkit.ChatColor;

public class Color {
    public static String Colorize(String text) {
        return ChatColor.translateAlternateColorCodes('&', text);
    }
}
