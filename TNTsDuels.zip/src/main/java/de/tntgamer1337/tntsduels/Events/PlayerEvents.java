package de.tntgamer1337.tntsduels.Events;

import de.tntgamer1337.tntsduels.BrokenBlock;
import de.tntgamer1337.tntsduels.TNTsDuels;
import de.tntgamer1337.tntsduels.managers.ArenaManager;
import de.tntgamer1337.tntsduels.managers.ConfigManager;
import de.tntgamer1337.tntsduels.managers.PlayerStatsManager;
import java.util.ArrayList;
import java.util.List;

import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.command.CommandSender;
import org.bukkit.command.ConsoleCommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.metadata.MetadataValue;
import org.bukkit.plugin.Plugin;

public class PlayerEvents implements Listener {
    private ArrayList<Block> Blocks = new ArrayList<>();
    private ArrayList<BrokenBlock> BrokenBlocks = new ArrayList<>();

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        TNTsDuels plugin = TNTsDuels.getInstance();
        FileConfiguration config = plugin.getConfig();
        Player p = e.getPlayer();
        String uuid = p.getUniqueId().toString();
        if (!config.contains(uuid))
            ConfigManager.setUpPlayer(p);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        TNTsDuels plugin = TNTsDuels.getInstance();
        Player p = e.getPlayer();
        p.removeMetadata("inDuel", (Plugin)plugin);
        p.removeMetadata("inQueue", (Plugin)plugin);
    }

    @EventHandler
    public void onBlockBreak(BlockBreakEvent e) {
        Player p = e.getPlayer();
        if (p.hasMetadata("inDuel")) {
            if (e.getBlock().hasMetadata("placedInDuel")) {
                String blockArenaName = null;
                List<MetadataValue> mtadata = e.getBlock().getMetadata("placedInDuel");
                for (MetadataValue value : mtadata) {
                    if (value.getOwningPlugin().getName().equals("TNTsDuels")) {
                        blockArenaName = value.asString();
                        break;
                    }
                }
                String arenaName = null;
                List<MetadataValue> metadata = p.getMetadata("inDuel");
                for (MetadataValue value : metadata) {
                    if (value.getOwningPlugin().getName().equals("TNTsDuels")) {
                        arenaName = value.asString();
                        break;
                    }
                }
                if (!arenaName.equals(blockArenaName)) {
                    e.setCancelled(true);
                } else {
                    this.Blocks.remove(e.getBlock());
                }
            } else {
                //e.setCancelled(true);
                Block block = e.getBlock();
                BrokenBlocks.add(new BrokenBlock(block.getLocation(), block.getType(), block.getWorld()));
                Bukkit.getConsoleSender().sendMessage(TNTsDuels.prefix+"Added BrokenBlock.");
            }
            return;
        } else {
            if (!p.getGameMode().equals(GameMode.CREATIVE)) {
                e.setCancelled(true);
            }
        }
    }

    @EventHandler
    public void onBlockPlace(BlockPlaceEvent e) {
        Player p = e.getPlayer();
        TNTsDuels plugin = TNTsDuels.getInstance();
        if (p.hasMetadata("inDuel")) {
            String arenaName = null;
            List<MetadataValue> metadata = p.getMetadata("inDuel");
            for (MetadataValue value : metadata) {
                if (value.getOwningPlugin().getName().equals("TNTsDuels")) {
                    arenaName = value.asString();
                    break;
                }
            }
            e.getBlock().setMetadata("placedInDuel", (MetadataValue)new FixedMetadataValue((Plugin)plugin, arenaName));
            Block b = e.getBlock();
            this.Blocks.add(b);
            return;
        }
    }

    @EventHandler
    public void onPlayerDeath(PlayerDeathEvent e) {
        TNTsDuels plugin = TNTsDuels.getInstance();
        Player p = e.getEntity();
        if (p != null) {
            Player killer = p.getKiller();
            if (killer != null &&
                    p.hasMetadata("inDuel") && killer.hasMetadata("inDuel")) {
                String str = null;
                List<MetadataValue> metadata = p.getMetadata("inDuel");
                for (MetadataValue value : metadata) {
                    if (value.getOwningPlugin().getName().equals("TNTsDuels")) {
                        str = value.asString();
                        break;
                    }
                }
                ConsoleCommandSender consoleCommandSender = Bukkit.getConsoleSender();
                Bukkit.dispatchCommand((CommandSender)consoleCommandSender, "title @a times 20 100 20");
                Bukkit.dispatchCommand((CommandSender)consoleCommandSender, "title @a subtitle {\"text\":\"WOW\",\"bold\":true,\"italic\":true,\"underlined\":true,\"color\":\"gold\"}");
                Bukkit.dispatchCommand((CommandSender)consoleCommandSender, "title @a title [\"\",{\"text\":\"" + killer.getName() + " \",\"bold\":true,\"color\":\"green\"},{\"text\":\"Won the Duel!\",\"bold\":true,\"color\":\"red\"}]");
                killer.removeMetadata("inDuel", (Plugin)plugin);
                killer.teleport(ArenaManager.getArenaLobby(str));
                killer.getInventory().clear();
                Bukkit.dispatchCommand((CommandSender)consoleCommandSender, "kill @e[type=item]");
                removePlacedDuelBlocks();
                setBackBrokenBlocks();
                PlayerStatsManager.addGamePlayed(killer);
                PlayerStatsManager.addWin(killer);
            } else {
                if (p.hasMetadata("inDuel")) {
                    String arenaName = null;
                    List<MetadataValue> mtadata = p.getMetadata("inDuel");
                    for (MetadataValue value : mtadata) {
                        if (value.getOwningPlugin().getName().equals("TNTsDuels")) {
                            arenaName = value.asString();
                            break;
                        }
                    }
                    for (Player player : Bukkit.getOnlinePlayers()) {
                        if (player.hasMetadata("inDuel")) {
                            String aarenaName = null;
                            List<MetadataValue> metadata = player.getMetadata("inDuel");
                            for (MetadataValue value : metadata) {
                                if (value.getOwningPlugin().getName().equals("TNTsDuels") &&
                                        player.getName() != p.getName()) {
                                    aarenaName = value.asString();
                                    break;
                                }
                            }
                            if (aarenaName != null &&
                                    aarenaName.equals(arenaName)) {
                                player.getInventory().clear();
                                ConsoleCommandSender consoleCommandSender = Bukkit.getConsoleSender();
                                Bukkit.dispatchCommand((CommandSender)consoleCommandSender, "title @a times 20 100 20");
                                Bukkit.dispatchCommand((CommandSender)consoleCommandSender, "title @a subtitle {\"text\":\"WOW\",\"bold\":true,\"italic\":true,\"underlined\":true,\"color\":\"gold\"}");
                                Bukkit.dispatchCommand((CommandSender)consoleCommandSender, "title @a title [\"\",{\"text\":\"" + player.getName() + " \",\"bold\":true,\"color\":\"green\"},{\"text\":\"Won the Duel!\",\"bold\":true,\"color\":\"red\"}]");
                                player.removeMetadata("inDuel", (Plugin)plugin);
                                player.teleport(ArenaManager.getArenaLobby(arenaName));
                                Bukkit.dispatchCommand((CommandSender)consoleCommandSender, "kill @e[type=item]");
                                removePlacedDuelBlocks();
                                setBackBrokenBlocks();
                                PlayerStatsManager.addGamePlayed(player);
                                PlayerStatsManager.addWin(player);
                            }
                        }
                    }
                }
            }
        }
        String arenaName = null;
        List<MetadataValue> mtadata = p.getMetadata("inDuel");
        for (MetadataValue value : mtadata) {
            if (value.getOwningPlugin().getName().equals("TNTsDuels")) {
                arenaName = value.asString();
                break;
            }
        }
        for (Player player : Bukkit.getOnlinePlayers()) {
            if (player.hasMetadata("inDuel")) {
                String aarenaName = null;
                List<MetadataValue> metadata = player.getMetadata("inDuel");
                for (MetadataValue value : metadata) {
                    if (value.getOwningPlugin().getName().equals("TNTsDuels") &&
                            player.getName() != p.getName()) {
                        aarenaName = value.asString();
                        break;
                    }
                }
                if (aarenaName != null &&
                        aarenaName.equals(arenaName)) {
                    player.getInventory().clear();
                    ConsoleCommandSender consoleCommandSender = Bukkit.getConsoleSender();
                    Bukkit.dispatchCommand((CommandSender)consoleCommandSender, "title @a times 20 100 20");
                    Bukkit.dispatchCommand((CommandSender)consoleCommandSender, "title @a subtitle {\"text\":\"WOW\",\"bold\":true,\"italic\":true,\"underlined\":true,\"color\":\"gold\"}");
                    Bukkit.dispatchCommand((CommandSender)consoleCommandSender, "title @a title [\"\",{\"text\":\"" + player.getName() + " \",\"bold\":true,\"color\":\"green\"},{\"text\":\"Won the Duel!\",\"bold\":true,\"color\":\"red\"}]");
                    player.removeMetadata("inDuel", (Plugin)plugin);
                    player.teleport(ArenaManager.getArenaLobby(arenaName));
                    Bukkit.dispatchCommand((CommandSender)consoleCommandSender, "kill @e[type=item]");
                    removePlacedDuelBlocks();
                    setBackBrokenBlocks();
                    PlayerStatsManager.addGamePlayed(player);
                    PlayerStatsManager.addWin(player);
                }
            }
        }
    }

    @EventHandler
    public void onPlayerRespawnEvent(PlayerRespawnEvent e) {
        TNTsDuels plugin = TNTsDuels.getInstance();
        Player p = e.getPlayer();
        String arenaName = null;
        List<MetadataValue> metadata = p.getMetadata("inDuel");
        for (MetadataValue value : metadata) {
            if (value.getOwningPlugin().getName().equals("TNTsDuels")) {
                arenaName = value.asString();
                break;
            }
        }
        if (arenaName != null) {
            p.removeMetadata("inDuel", (Plugin)plugin);
            p.teleport(ArenaManager.getArenaLobby(arenaName));
            ConsoleCommandSender consoleCommandSender = Bukkit.getConsoleSender();
            Bukkit.dispatchCommand((CommandSender)consoleCommandSender, "kill @e[type=item]");
            if (p.getKiller() instanceof Player) {
                PlayerStatsManager.addGamePlayed(p);
                removePlacedDuelBlocks();
                setBackBrokenBlocks();
            }
        } else {
            p.teleport(new Location(p.getWorld(), 0.0D, 150.0D, 0.0D, 0.0F, 0.0F));
        }
    }

    @EventHandler
    public void onDamageEvent(EntityDamageEvent e) {
        EntityType type = e.getEntityType();
        if (type == EntityType.PLAYER) {
            Player p = (Player)e.getEntity();
            if (!p.hasMetadata("inDuel"))
                e.setCancelled(true);
        }
    }

    @EventHandler
    public void onAsnycPlayerChatEvent(AsyncPlayerChatEvent e) {
        String msg = e.getMessage();
        Player player = e.getPlayer();
        if (msg.equals("addGame")) {
            PlayerStatsManager.addGamePlayed(player);
        } else if (msg.equals("addWin")) {
            PlayerStatsManager.addWin(player);
        }
    }

    public void removePlacedDuelBlocks() {
        TNTsDuels plugin = TNTsDuels.getInstance();
        Bukkit.getScheduler().runTask((Plugin)plugin, () -> {
            for (Block b : Blocks) {
                b.setType(Material.AIR);
            }
            Blocks.clear();
        });
    }

    public void setBackBrokenBlocks() {
        TNTsDuels plugin = TNTsDuels.getInstance();
        Bukkit.getScheduler().runTask((Plugin)plugin, () -> {
           for (BrokenBlock broken : BrokenBlocks) {
               World world = broken.getWorld();
               Location loc = broken.getLocation();
               Material type = broken.getMaterial();
               world.getBlockAt(loc).setType(type);
               Bukkit.getConsoleSender().sendMessage(TNTsDuels.prefix+"Fixed Broken Block.");
           }
           BrokenBlocks.clear();
        });
    }
}