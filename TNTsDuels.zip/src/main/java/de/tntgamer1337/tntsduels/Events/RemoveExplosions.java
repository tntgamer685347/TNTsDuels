package de.tntgamer1337.tntsduels.Events;

import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityExplodeEvent;

public class RemoveExplosions implements Listener {
    @EventHandler
    public void onEntityExplodeEVent(EntityExplodeEvent e) {
        e.setCancelled(true);
    }
}
