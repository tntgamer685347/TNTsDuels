package de.tntgamer1337.tntsduels;

import de.tntgamer1337.tntsduels.Events.PlayerEvents;
import de.tntgamer1337.tntsduels.Events.RemoveExplosions;
import de.tntgamer1337.tntsduels.commands.arenaCommand;
import de.tntgamer1337.tntsduels.commands.duelCommand;
import de.tntgamer1337.tntsduels.commands.queueCommand;
import de.tntgamer1337.tntsduels.tabcompletors.arenaTabCompletion;
import de.tntgamer1337.tntsduels.tabcompletors.duelTabCompletion;
import de.tntgamer1337.tntsduels.tabcompletors.queueTabCompletion;
import de.tntgamer1337.tntsduels.utilitys.Color;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.CommandExecutor;
import org.bukkit.event.Listener;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;

public final class TNTsDuels extends JavaPlugin {
    private static TNTsDuels instance;

    public static String prefix = Color.Colorize("&7[&6&lTNTsDuels&r&7] &r");

    public void onEnable() {
        getConfig().options().copyDefaults(true);
        saveConfig();
        instance = this;
        getServer().getPluginManager().registerEvents((Listener)new PlayerEvents(), (Plugin)this);
        getServer().getPluginManager().registerEvents((Listener)new RemoveExplosions(), (Plugin)this);
        getCommand("arena").setExecutor((CommandExecutor)new arenaCommand());
        getCommand("duel").setExecutor((CommandExecutor)new duelCommand());
        getCommand("queue").setExecutor((CommandExecutor)new queueCommand());
        getCommand("arena").setTabCompleter(new arenaTabCompletion());
        getCommand("duel").setTabCompleter(new duelTabCompletion());
        getCommand("queue").setTabCompleter(new queueTabCompletion());
        Bukkit.getConsoleSender().sendMessage(String.valueOf(prefix) + ChatColor.GREEN + "TNTsDuels: enabled");
    }

    public void onDisable() {
        Bukkit.getConsoleSender().sendMessage(String.valueOf(prefix) + ChatColor.RED + "TNTsDuels: disabled");
    }

    public static TNTsDuels getInstance() {
        return instance;
    }
}